import json
import pymssql
import os
import time
import logging
import boto3
import base64
import datetime
from botocore.exceptions import ClientError

#INSERT YOUR INFORMATION HERE##########################
#SECRET MANAGER INFO
secret_name = "<<INSERT SECRET NAME HERE>>"
region_name = "<<INSERT REGION HERE>>"
#######################################################

logger = logging.getLogger()
logger.setLevel(logging.DEBUG)

def get_slots(intent_request):
    return intent_request['currentIntent']['slots']

def elicit_slot(session_attributes, intent_name, slots, slot_to_elicit, message):
    return {
        'sessionAttributes': session_attributes,
        'dialogAction': {
            'type': 'ElicitSlot',
            'intentName': intent_name,
            'slots': slots,
            'slotToElicit': slot_to_elicit,
            'message': message
        }
    }

def delegate(session_attributes, slots):
    return {
        'sessionAttributes': session_attributes,
        'dialogAction': {
            'type': 'Delegate',
            'slots': slots
        }
    }

def build_validation_result(is_valid, violated_slot, message_content):
    if message_content is None:
        return {
            "isValid": is_valid,
            "violatedSlot": violated_slot,
        }

    return {
        'isValid': is_valid,
        'violatedSlot': violated_slot,
        'message': {'contentType': 'PlainText', 'content': message_content}
    }    
    
def close(session_attributes, fulfillment_state, message):
    response = {
        'sessionAttributes': session_attributes,
        'dialogAction': {
            'type': 'Close',
            'fulfillmentState': fulfillment_state,
            'message': message
        }
    }

    return response

    
def dispatch(intent_request):
    """
    Called when the user specifies an intent for this bot.
    """
    
    farmName = get_slots(intent_request)['WhatFarm']
    bugType = get_slots(intent_request)['WhatBug']
    bugStage = get_slots(intent_request)['WhatLifecycle']
    bugDateSeen = get_slots(intent_request)['WhenDidYouSeeIt']
    bugDensity = get_slots(intent_request)['WhatBugDensity']
    bugVacOwnership = get_slots(intent_request)['LygusBugVac']
    bugVacLastDate = get_slots(intent_request)['LastBugVacDate']
    bugVacLastTime = get_slots(intent_request)['LastBugVacTime']
    neighborBugsSeen = get_slots(intent_request)['WhatNeighborsHaveBugs']
    
    secret = json.loads(get_secret()["SecretString"])
    conn = pymssql.connect(secret["host"], secret["username"], secret["password"], secret["dbname"])
    cursor = conn.cursor()
    cursor.execute('insert into ChatBotResponses(FarmName, BugDateSeen, BugType, BugDensity, BugLifecycle, BugInOtherFields, BugVacOwnership, LastBugVacDateTime, ResponderPhoneNumber) Values(%s, %d, %s, %s, %s, %d, %s, %d, %s)', 
    (farmName, bugDateSeen, bugType, bugDensity, bugStage, neighborBugsSeen, bugVacOwnership, bugVacLastDate + ' ' + bugVacLastTime, intent_request['userId']))
    conn.commit()
    
    cursor = conn.cursor(as_dict=True)
    cursor.execute('select ID from ChatBotResponses where FarmName = %s', farmName)
    row = cursor.fetchone()
    farmID = row['ID']

    today = datetime.datetime.now()
    
    cursor = conn.cursor(as_dict=True)
    cursor.execute('insert into PestPlan(FarmID, GenerationDateTime) Values(%s, %s)', (farmID, today.strftime("%Y-%m-%d %H:%M:%S")))
    conn.commit()
    
    pestPlanID = cursor.lastrowid
    
    messageList = []
    
    for day in range(1, 6):
        dateRangeBegin = today.replace(hour=16, minute=00) + datetime.timedelta(days=day)
        dateRangeEnd = today.replace(hour=22, minute=00) + datetime.timedelta(days=day)
        cursor = conn.cursor(as_dict=True)
        cursor.execute("select avg(speed) as AverageSpeed from WeatherData where ForecastDateTime between %d and %d", (dateRangeBegin, dateRangeEnd))
        row = cursor.fetchone()
        if row['AverageSpeed'] < 5:
            cursor = conn.cursor()
            cursor.execute('insert into PestPlanStep(PlanID, BeginDateTime, EndDateTime) Values(%s, %d, %d)', 
            (pestPlanID, dateRangeBegin.strftime("%Y-%m-%d %H:%M"), dateRangeEnd.strftime("%Y-%m-%d %H:%M")))
            conn.commit()
            messageList.append(dateRangeBegin.strftime("%Y-%m-%d"))
    conn.close()
    
    message = "Based on the forecast for the next 5 days, the best time to run your lygus bug vacuum would be on:\n"
    
    for x in messageList:
        message = message + x + "\nBetween 4PM and 10PM."" \n"
    
    message = message + "We will text you each morning on the day you should be running your Lygus Bug Vacuum."

    return close(intent_request['sessionAttributes'],
                 'Fulfilled',
                 {'contentType': 'PlainText',
                  'content': message })

""" --- Main Handler --- """

def lambda_handler(event, context):
    """
    Route the incoming request based on intent.
    """

    os.environ['TZ'] = 'America/Los_Angeles'
    time.tzset()
    
    return dispatch(event)

def get_secret():
    global secret_name
    global region_name

    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )

    # In this sample we only handle the specific exceptions for the 'GetSecretValue' API.
    # See https://docs.aws.amazon.com/secretsmanager/latest/apireference/API_GetSecretValue.html
    # We rethrow the exception by default.

    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        if e.response['Error']['Code'] == 'DecryptionFailureException':
            # Secrets Manager can't decrypt the protected secret text using the provided KMS key.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InternalServiceErrorException':
            # An error occurred on the server side.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InvalidParameterException':
            # You provided an invalid value for a parameter.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InvalidRequestException':
            # You provided a parameter value that is not valid for the current state of the resource.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'ResourceNotFoundException':
            # We can't find the resource that you asked for.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
    else:
        # Decrypts secret using the associated KMS CMK.
        # Depending on whether the secret is a string or binary, one of these fields will be populated.
        if 'SecretString' in get_secret_value_response:
            secret = get_secret_value_response['SecretString']
        else:
            decoded_binary_secret = base64.b64decode(get_secret_value_response['SecretBinary'])
            
    return get_secret_value_response