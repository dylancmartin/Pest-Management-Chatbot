import json
import pymssql
import os
import time
import datetime
import logging
import boto3
import base64
from botocore.exceptions import ClientError

#INSERT YOUR INFORMATION HERE##########################
#SECRET MANAGER INFO
secret_name = "<<INSERT SECRET NAME HERE>>"
region_name = "<<INSERT REGION HERE>>"
#######################################################


logger = logging.getLogger()
logger.setLevel(logging.DEBUG)

""" --- Helper Methods --- """

def get_slots(intent_request):
    return intent_request['currentIntent']['slots']

def elicit_slot(session_attributes, intent_name, slots, slot_to_elicit, message):
    return {
        'sessionAttributes': session_attributes,
        'dialogAction': {
            'type': 'ElicitSlot',
            'intentName': intent_name,
            'slots': slots,
            'slotToElicit': slot_to_elicit,
            'message': message
        }
    }

def delegate(session_attributes, slots):
    return {
        'sessionAttributes': session_attributes,
        'dialogAction': {
            'type': 'Delegate',
            'slots': slots
        }
    }

def build_validation_result(is_valid, violated_slot, message_content):
    if message_content is None:
        return {
            "isValid": is_valid,
            "violatedSlot": violated_slot,
        }

    return {
        'isValid': is_valid,
        'violatedSlot': violated_slot,
        'message': {'contentType': 'PlainText', 'content': message_content}
    }    
    
def close(session_attributes, fulfillment_state, message):
    response = {
        'sessionAttributes': session_attributes,
        'dialogAction': {
            'type': 'Close',
            'fulfillmentState': fulfillment_state,
            'message': message
        }
    }

    return response

    
def dispatch(intent_request):
    today = datetime.datetime.now() + datetime.timedelta(days=3)
    secret = json.loads(get_secret()["SecretString"])

    conn = pymssql.connect(secret["host"], secret["username"], secret["password"], secret["dbname"])
    cursor = conn.cursor(as_dict=True)
    cursor.execute("select f.FarmName, BeginDateTime, EndDateTime, PhoneNumber, cast(BeginDateTime as time(0)) as BeginTime, cast(EndDateTime as time(0)) as EndTime from pestplan p inner join pestplanstep s on p.planid = s.planid inner join Farm f on f.ID = p.farmid where cast(s.BeginDateTime as date) = %d",  (today.strftime("%Y-%m-%d")))
 
    sns = boto3.client('sns')   

    for row in cursor:
        bugVacMessage = "This is a reminder for " + str(row["FarmName"]) + ". You should be vacuuming your field today between " + str(row["BeginTime"]) + " and " + str(row["EndTime"]) + ".\n"
        bugVacMessage = bugVacMessage + "Don't forget that the correct speed for the bug Vacuum is 2 miles per hour and "
        bugVacMessage = bugVacMessage + "Vacuuming at the canopy height of the plant is 60% more effective than vacuuming 6 inches above the canopy."
        sns.publish(PhoneNumber = str(row["PhoneNumber"]), Message = bugVacMessage)
       
    conn.close()

""" --- Main Handler --- """

def lambda_handler(event, context):
    
    """
    Route the incoming request based on intent.
    """
    os.environ['TZ'] = 'America/Los_Angeles'
    time.tzset()
    print(json.dumps(event));

    return dispatch(event)
    
    
def get_secret():
    global secret_name
    global region_name

    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )

    # In this sample we only handle the specific exceptions for the 'GetSecretValue' API.
    # See https://docs.aws.amazon.com/secretsmanager/latest/apireference/API_GetSecretValue.html
    # We rethrow the exception by default.

    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        if e.response['Error']['Code'] == 'DecryptionFailureException':
            # Secrets Manager can't decrypt the protected secret text using the provided KMS key.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InternalServiceErrorException':
            # An error occurred on the server side.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InvalidParameterException':
            # You provided an invalid value for a parameter.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InvalidRequestException':
            # You provided a parameter value that is not valid for the current state of the resource.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'ResourceNotFoundException':
            # We can't find the resource that you asked for.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
    else:
        # Decrypts secret using the associated KMS CMK.
        # Depending on whether the secret is a string or binary, one of these fields will be populated.
        if 'SecretString' in get_secret_value_response:
            secret = get_secret_value_response['SecretString']
        else:
            decoded_binary_secret = base64.b64decode(get_secret_value_response['SecretBinary'])
            
    return get_secret_value_response