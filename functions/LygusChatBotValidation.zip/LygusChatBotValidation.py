import json 
import pymssql 
import os 
import time 
import logging 
import boto3 
import base64 
from botocore.exceptions import ClientError 
 
#INSERT YOUR INFORMATION HERE##########################
#SECRET MANAGER INFO
secret_name = "<<INSERT SECRET NAME HERE>>"
region_name = "<<INSERT REGION HERE>>"
#######################################################
 
logger = logging.getLogger()
logger.setLevel(logging.DEBUG)

def get_slots(intent_request): 
    return intent_request['currentIntent']['slots'] 
 
def elicit_slot(session_attributes, intent_name, slots, slot_to_elicit, message): 
    return { 
        'sessionAttributes': session_attributes, 
        'dialogAction': { 
            'type': 'ElicitSlot', 
            'intentName': intent_name, 
            'slots': slots, 
            'slotToElicit': slot_to_elicit, 
            'message': message 
        } 
    } 
 
def delegate(session_attributes, slots): 
    return { 
        'sessionAttributes': session_attributes, 
        'dialogAction': { 
            'type': 'Delegate', 
            'slots': slots 
        } 
    } 
 
def build_validation_result(is_valid, violated_slot, message_content, sessionAttributes): 
    if message_content is None: 
        return { 
            "isValid": is_valid, 
            "violatedSlot": violated_slot, 
        } 
 
    return { 
        'isValid': is_valid, 
        'violatedSlot': violated_slot, 
        'sessionAttributes': {'FarmName': sessionAttributes}, 
        'message': {'contentType': 'PlainText', 'content': message_content} 
    }  
 
def close(fulfillment_state, message): 
    return { 
        'sessionAttributes': {}, 
        'dialogAction': { 
            'type': 'Close', 
            'fulfillmentState': fulfillment_state, 
            'message': { 
                'contentType': 'PlainText', 
                'content': message } 
        } 
    } 
 
def validate_inputs(callerPhoneNumber, bugType, bugVacOwnership): 
     
    if callerPhoneNumber is not None: 
        secret = json.loads(get_secret()["SecretString"]) 
        conn = pymssql.connect(secret["host"], secret["username"], secret["password"], secret["dbname"]) 
        cursor = conn.cursor(as_dict=True) 
        cursor.execute('select * from farm where PhoneNumber =%s', callerPhoneNumber) 
        
        row = cursor.fetchone()
        
        if row is None: 
            return build_validation_result(False, "WhatFarm", "I'm sorry, I don't recognize the number you're calling from.  Please contact the California Strawberry Commission (www.calstrawberry.com) if you think you should have access.", "{}") 
        
    return build_validation_result(True, None, 'Test', row["FarmName"]) 
 
def validate_intents(intent_request): 
 
    farmName = get_slots(intent_request)['WhatFarm'] 
    bugType = get_slots(intent_request)['WhatBug'] 
    bugStage = get_slots(intent_request)['WhatLifecycle'] 
    bugDateSeen = get_slots(intent_request)['WhenDidYouSeeIt'] 
    bugDensity = get_slots(intent_request)['WhatBugDensity'] 
    bugVacOwnership = get_slots(intent_request)['LygusBugVac'] 
    bugVacLastDate = get_slots(intent_request)['LastBugVacDate'] 
    bugVacLastTime = get_slots(intent_request)['LastBugVacTime'] 
    neighborBugsSeen = get_slots(intent_request)['WhatNeighborsHaveBugs'] 
    callerPhoneNumber = intent_request['userId']
    
    if farmName is not None:
        if farmName  == "No":
            return close("Fulfilled", "Sorry, we can't determine your identity")
     
    if bugType is not None: 
        if bugType == "No": 
            return close("Fulfilled", "We currently only have best practices for managing Lygus Bugs.  We will be adding more bugs in the future so please come back again.") 
     
    if bugVacOwnership is not None: 
        if bugVacOwnership == "No": 
            return close("Fulfilled", "We currently only have best practices for running a Lygus Bug Vacuum.  We will be adding in more methods of pest management soon.  Please come back again.") 
     
    validation_result = validate_inputs(callerPhoneNumber, bugType, bugVacOwnership) 
    
    source = intent_request['invocationSource'] 
 
    if source == 'DialogCodeHook': 
        slots = get_slots(intent_request) 
     
        if not validation_result['isValid']: 
            slots[validation_result['violatedSlot']] = None 
            return elicit_slot(intent_request['sessionAttributes'], 
                               intent_request['currentIntent']['name'], 
                               slots, 
                               validation_result['violatedSlot'], 
                               validation_result['message']) 
        else: 
            print(intent_request['sessionAttributes'])
            print(validation_result['sessionAttributes'])
            #output_session_attributes = intent_request['sessionAttributes'] if intent_request['sessionAttributes'] is not None else {} 
            output_session_attributes = validation_result['sessionAttributes'] if validation_result['sessionAttributes'] is not None else {} 
            return delegate(output_session_attributes, get_slots(intent_request)) 
     
     
def dispatch(intent_request): 
    """ 
    Called when the user specifies an intent for this bot. 
    """ 
 
    intent_name = intent_request['currentIntent']['name'] 
 
    # Dispatch to your bot's intent handlers 
    if intent_name == 'PestHelp': 
       return validate_intents(intent_request) 
 
    raise Exception('Intent with name ' + intent_name + ' not supported') 
 
 
""" --- Main Handler --- """ 
 
def lambda_handler(event, context): 
     
    """ 
    Route the incoming request based on intent. 
    """ 
     
    os.environ['TZ'] = 'America/Los_Angeles' 
    time.tzset() 
    #logger.debug('event.bot.name={}'.format(event['bot']['name'])) 
    #print event
    return dispatch(event) 
     
def get_secret():
    global secret_name
    global region_name

    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )

    # In this sample we only handle the specific exceptions for the 'GetSecretValue' API.
    # See https://docs.aws.amazon.com/secretsmanager/latest/apireference/API_GetSecretValue.html
    # We rethrow the exception by default.

    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        if e.response['Error']['Code'] == 'DecryptionFailureException':
            # Secrets Manager can't decrypt the protected secret text using the provided KMS key.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InternalServiceErrorException':
            # An error occurred on the server side.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InvalidParameterException':
            # You provided an invalid value for a parameter.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InvalidRequestException':
            # You provided a parameter value that is not valid for the current state of the resource.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'ResourceNotFoundException':
            # We can't find the resource that you asked for.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
    else:
        # Decrypts secret using the associated KMS CMK.
        # Depending on whether the secret is a string or binary, one of these fields will be populated.
        if 'SecretString' in get_secret_value_response:
            secret = get_secret_value_response['SecretString']
        else:
            decoded_binary_secret = base64.b64decode(get_secret_value_response['SecretBinary'])
            
    return get_secret_value_response